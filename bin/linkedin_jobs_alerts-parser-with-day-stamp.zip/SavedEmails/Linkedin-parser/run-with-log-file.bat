C:\SavedEmails\Linkedin-parser\linkedin_jobs_enhanced-with-day-stamp-v.2.exe >"C:\SavedEmails\Linkedin-parser\log-file.txt"
