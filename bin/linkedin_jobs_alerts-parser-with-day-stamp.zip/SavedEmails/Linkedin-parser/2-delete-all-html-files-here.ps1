# PowerShell script to DELETE .html files only in the ROOT of Linkedin-parser with simple Y-confirmation

$targetDir = "C:\SavedEmails\Linkedin-parser"

Write-Host "=== DANGER: ROOT HTML FILE PURGE ===" -ForegroundColor Red
Write-Host "This will PERMANENTLY DELETE all .html files ONLY in the ROOT of:" -ForegroundColor Yellow
Write-Host "  $targetDir" -ForegroundColor Yellow
Write-Host "Subfolders and their files will NOT be touched." -ForegroundColor Green

# Check if directory exists
if (-not (Test-Path -Path $targetDir)) {
    Write-Error "Directory does not exist: $targetDir"
    exit 1
}

# Get only .html files in the root (no -Recurse)
$htmlFiles = Get-ChildItem -Path $targetDir -Filter "*.html" -File
$fileCount = $htmlFiles.Count

if ($fileCount -eq 0) {
    Write-Host "No .html files found in root of $targetDir" -ForegroundColor Green
    exit 0
}

Write-Host "`nFound $fileCount .html file(s) in ROOT to delete:" -ForegroundColor Cyan
$htmlFiles | Select-Object -First 5 | ForEach-Object {
    Write-Host "  - $($_.FullName)" -ForegroundColor White
}
if ($fileCount -gt 5) {
    Write-Host "  ... and $($fileCount - 5) more files" -ForegroundColor Gray
}

# Simple confirmation
$confirm = Read-Host "`nType 'Y' to confirm purge (anything else to cancel)"
if ($confirm -ne "Y") {
    Write-Host "Operation cancelled." -ForegroundColor Green
    exit 0
}

Write-Host "`nDeleting $fileCount file(s)..." -ForegroundColor Yellow

$deletedCount = 0
foreach ($file in $htmlFiles) {
    Remove-Item -Path $file.FullName -Force
    $deletedCount++
    Write-Host "Deleted: $($file.Name)" -ForegroundColor Red
}

Write-Host "`nPurge complete. Deleted $deletedCount .html file(s) from ROOT of $targetDir" -ForegroundColor Green
